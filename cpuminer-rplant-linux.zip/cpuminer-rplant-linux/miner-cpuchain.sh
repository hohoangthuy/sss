#!/bin/sh
while [ 1 ]; do
./cpuminer-sse2 -a cpupower -o stratum+tcp://cpuchain.minermore.com:4551 -u enterserver.worker -p x
done
